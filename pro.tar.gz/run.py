import argparse
import socks
import socket
from concurrent.futures import ThreadPoolExecutor
import time

# Fungsi untuk memeriksa proxy menggunakan soket mentah
def check_proxy(proxy, protocol, host, port, timeout=0.5):
    try:
        ip, port_proxy = proxy.split(":")
        port_proxy = int(port_proxy)

        if protocol == "socks4":
            socks.set_default_proxy(socks.SOCKS4, ip, port_proxy)
        elif protocol == "socks5":
            socks.set_default_proxy(socks.SOCKS5, ip, port_proxy)
        elif protocol in ["http", "https"]:
            socks.set_default_proxy(socks.HTTP, ip, port_proxy)
        else:
            return False

        socket.socket = socks.socksocket
        s = socket.socket()
        s.settimeout(timeout)
        s.connect((host, port))
        s.close()
        return True
    except Exception:
        return False

# Fungsi untuk menyimpan proxy aktif langsung ke file
def save_proxy_to_file(proxy):
    with open("good.txt", "a") as good_file:  # Mode append agar menambahkan hasil
        good_file.write(proxy + "\n")
    print(f"Saved active proxy: {proxy}")

# Fungsi utama untuk membaca daftar proxy dan memprosesnya
def process_proxies(file_path, protocol, host, port, timeout, sleep, threads):
    with open(file_path, "r") as file:
        proxies = [line.strip() for line in file.readlines()]

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {
            executor.submit(check_proxy, proxy, protocol, host, port, timeout): proxy
            for proxy in proxies
        }
        for future in futures:
            proxy = futures[future]
            if future.result():
                print(f"[ACTIVE] {proxy}")
                save_proxy_to_file(proxy)  # Simpan langsung setelah proxy valid
            else:
                print(f"[DEAD] {proxy}")
            time.sleep(sleep)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Proxy Checker Script for stratum+tcp")
    parser.add_argument("-x", "--file", required=True, help="File containing proxy list")
    parser.add_argument("-p", "--protocol", required=True, choices=["http", "https", "socks4", "socks5"], help="Proxy protocol")
    parser.add_argument("--timeout", type=float, default=0.5, help="Timeout for proxy connection (default: 0.5s)")
    parser.add_argument("--sleep", type=float, default=0.5, help="Sleep duration between checks (default: 0.5s)")
    parser.add_argument("--threads", type=int, default=4, help="Number of threads (default: 4)")

    args = parser.parse_args()

    # Host dan port dari URL stratum
    url = "stratum+tcp://na.luckpool.net:3956"
    host = url.split("//")[1].split(":")[0]
    port = int(url.split(":")[-1])

    process_proxies(args.file, args.protocol, host, port, args.timeout, args.sleep, args.threads)
